# Index operator [] = Gives acces to a sequnce's elements(str, list, update)

name = "Technology Secret"
if(name[0].islower()):
    name = name.capitalize()

first_name = name[1:3].upper()
last_name = name[4:3].lower()
last_char = name[-1]


print(first_name)
print(last_name)
print(last_char) 