# Functions= > A block of code which is executed only when it is called.
            # Or- Block of Staements that perfrom a specfic task.

# Declaration: 

# def func_name(param1, param2...):   function definition 
    # some code/work
    # return Value

# func_name(arg1, arg2 ..)  function call// or arguments pass


# def hello() : 
#     print("Hello! Shailesh")
#     print("Hello! Shailesh")

# hello()
# hello()   #Call Functions Name


# Function Call But Passing Arguments 

# def hello(name):
#     print ("This is your channel Name")
#     print ("Yes, My Channel name is"+ name)

# hello("Technology Secret !!!")



# Function Call But Passing 2 + Arguments Passing 

def channel(chanl_fastname, chanl_lastname,time):
    print("Hello "+ chanl_fastname+" "+chanl_lastname)
    print("Your Chnannel Time is " + str(time)+" ago created" )
    print("Have a Good Work, Keep it up ")

channel("Technology", " Secret", 2021)

# Example 1:  Calucatae Sum 

def sum_Cal(a , b):
    sum = a + b
    print(sum)
    return sum

sum_Cal(10, 5)
sum_Cal(10, 50)
sum_Cal(10, 25)


# Some Important Practice Questions 
# Q1. WAF to print the length of a list. (List is the parameter)
# Q2. WAF to print the elements of a list in a single line(list is the paramter)
# Q3. WAF to find the factorial of n (n is the parameter
# Q4. WAF to convert USD to INR 

