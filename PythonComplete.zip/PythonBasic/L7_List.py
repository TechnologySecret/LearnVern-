print("List")
# Ans:  Used to store a multiple items in a single varible

food  = ["Pizza", "Humburger","Hotdog", "Spaghetti", "Pudding"]

food [0] = "Sushi"  # when want for replace places of 0 
# food.append ("ice-cream")  # add last index
# food.remove("Hotdog") # remove from particular places  
# food.pop()  # remove the last index elements
# food.insert(0, " cake")
food.sort()




print(food[1]) # print particular index number

for x in food :
     print (x)

#2D Lists = a lists of lists. 
print("2D Lists :  This is work like just 2D-array Systems ")

drinks =["COffee", "Soda", "Tea", "Pizz"]
dinner =["Pizza", "Haumbarguer", "HotDog", "Rice-Plus"]
dessert= ["Cake","Ice-Cream",]

food2= [drinks,dinner, dessert]
print(food2[2][1])








