#Import Function in Python . 
import math
pi = 3.14
x= 11
y=22
z= 33

print(round(pi))
print(math.ceil(pi))
print(math.floor(pi))
print(abs(pi))
print(pow(pi,2))
print(math.sqrt(402))
print(max (x,y,z))
print(min (x,y,z))



