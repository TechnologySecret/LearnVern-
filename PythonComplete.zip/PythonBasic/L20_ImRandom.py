import random
# Example 1:
x= random.randint(1,10)
print(x)      # This print function execute random number from 1 to 10.

# Example 2:
y= random.random()  

myList = ['Rock','Rose','Shailu']
z= random.choice(myList)
print(z)

# Example 3:
cards= [1,2,3,4,5,6,7,8,9 ,"J","Q","K","A"]
random.shuffle(cards)
print(cards)






