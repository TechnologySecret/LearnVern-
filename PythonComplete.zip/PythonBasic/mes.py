def hello():
    print("Hello Have a nice day!!")

def bye():
    print("Bye ! Have a wonderful time")