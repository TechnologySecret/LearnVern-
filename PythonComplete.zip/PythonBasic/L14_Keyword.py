# Keyword arguments= arguments processd by an identifier when we pass then to functions
#                 The order of the arguments doesn't matter unlike positional arguments. 
#                 Python known the names of the arguments that our functions recives.. 

# Example: 

def hello(first, middle, last):
    print("Hello"+first+" "+middle+" "+last)
hello(last ="Secret", middle =" Technical",first=" Technology")

