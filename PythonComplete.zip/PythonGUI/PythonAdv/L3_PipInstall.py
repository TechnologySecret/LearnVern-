# Python pip:- It is pakage Manager and modules from Python Package Index
# *********************************

# included for Python 13.01 Versions: Some Command :

#       Open Command Prompt :- Win + R  (cmd)
''' 
    help:                       pip
    check:                      pip --version
    update:                     pip install --upgrade pip 
    install pakages:            pip list
    check outdated pakages:     pip install "package name"  --upgrade
    update a pakages:           pip install "package name"
    
****************************************************
'''