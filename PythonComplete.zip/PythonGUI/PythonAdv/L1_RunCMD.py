# Q1. Run a python file using command Prompt 

# Following These Step :  
#     1. Save file as  .py (Python file)
#     2. go to command prompt navigate to directory w/ 
#         your file:  cd C:Python file __path__
#         invoke python interpreter + script:

# Example :  USing CMD RUn PYTHON FILE 

print("This is simple test file using cmd to run python file")

name = str(input("Enter Your Name:- "))   #you can remove str and close brakets
print("Your Name is :"+name)
           
