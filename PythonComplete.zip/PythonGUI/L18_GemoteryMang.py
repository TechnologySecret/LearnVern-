# Q: Create a proram login form using python stored data, name, email, passwords

from tkinter import*
# grid()  = geometry manager that organizes Widget in a table-like structure in a parents

window = Tk()

titleLabel = Label(window, text= "Enter Your Info", font=("Arial",25)).grid(row=0, column=0, columnspan=2)

firstNameLabel = Label(window, text="First name:", width=20, bg="red").grid( row=1, column=0)
firstNameEntry = Entry(window).grid(row=1, column=1)


lastNameLabel = Label(window, text="Last name:", bg="green").grid( row=2, column=0)
lastNameEntry = Entry(window).grid(row=2, column=1)

emailLabel = Label(window, text="Enter Email:",bg="blue").grid( row=3, column=0)
emailEntry = Entry(window).grid(row=3, column=1)

submitButton = Button(window, text="Submit").grid(row =4, column=0, columnspan=2)

window.mainloop()