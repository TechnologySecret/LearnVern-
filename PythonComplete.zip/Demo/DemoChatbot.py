from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer

# Step 1: Create a chatbot instance
chatbot = ChatBot('MyBot')

# Step 2: Train the chatbot
trainer = ChatterBotCorpusTrainer(chatbot)
trainer.train('chatterbot.corpus.english')

# Step 3: Chat with the chatbot
print("Hello! I am your chatbot. Type 'exit' to end the conversation.")

while True:
    user_input = input("You: ")
    
    if user_input.lower() == 'exit':
        print("ChatBot: Goodbye!")
        break

    response = chatbot.get_response(user_input)
    print(f"ChatBot: {response}")
