def hello():
    print("Hello")

# print(hello)   PrintMemory Address in function

# Output: <function hello at 0x000001F1B432A340>
hi = hello
# hello()    Memeory Address of hello function
# hi()

say = print
say("Whoa!, I can't belive this works: 0 ")

  