# map () = applies a function to each item in an iterable (list, tuple, etc)
# map(function, iterable)

store = [("shirt",20.00),
         ("paints",25.00),
         ("jacket",50.00),
         ("socks",10.00)]

# Question:  Convert Dolloar to Euro using lambda functions

to_euros = lambda data:(data[0], data[1]*0.82)

store_euros = list(map(to_euros, store))

print("\n Store Product Value in Euros:")

for i in store_euros:
    print(i)

# function check in dollors
to_dollars = lambda data:(data[0], data[1]/0.82)
store_dollars = list(map(to_dollars, store))
print("\n Store Product Value in Dollor Check Right Or Wrong:")
for j in store_dollars:
    print(j)
    


