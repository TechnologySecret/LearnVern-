# WalRus Operator {" := "}  New to Python 3.8 
# assignement experssion aka walrus operator,
# assigns values to variables as part of a larger experssion 

# Step1 
# foods = list()
# while True:
#     food = input("What food do you like?:")
#     if food == "quit":
#         break
#     foods.append (food)

# Same Code Write in WalRus Operator,

# Step 2

foods = list()
while food := input("What Type of Food Like You: ") !="quit":
    foods.append(food)

# This is same as Step 1 Example.













